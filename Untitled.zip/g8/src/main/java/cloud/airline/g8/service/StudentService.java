package cloud.airline.g8.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cloud.airline.g8.repository.StudentRepository;

@Service
public class StudentService {

    @Autowired
    private final StudentRepository studentRepository;
    
    @GetMapping("/home")
    
    
}

