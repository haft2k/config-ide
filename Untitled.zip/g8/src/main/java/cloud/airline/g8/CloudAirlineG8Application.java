package cloud.airline.g8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudAirlineG8Application {

    public static void main( String[] args ) {

        SpringApplication.run(CloudAirlineG8Application.class, args);

    }

}
