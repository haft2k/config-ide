package cloud.airline.g8.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import cloud.airline.g8.model.Student;

/*
 * no use @Repository, annotation just use in Class
 * this interface is ORM MySql, mapping data in table student to object student
 */
public interface StudentRepository extends JpaRepository<Student, Long> {

}
