
package cloud.airline.g8.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cloud.airline.g8.service.StudentService;

/*
 * @Controller return View HTML
 * 
 * @RestController use for API
 */
@Controller
@RequestMapping( "/" ) // endpoint root is /
public class UserController {

    // Inject Student
//    @Autowired
//    private final StudentService studentService;

}
