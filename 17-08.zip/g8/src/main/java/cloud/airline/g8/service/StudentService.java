package cloud.airline.g8.service;

import java.util.List;

import cloud.airline.g8.model.Student;

public interface StudentService {

    List<Student> getAllStudent();

    Student findByName( String fullName );
    
    List<Student> lstStudentGreaterAvg();
    

}
