/*
 * GumBox Inc
 * (c) 2022 GumBox Inc. Viet Nam
 *
 */
package cloud.airline.g8.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import cloud.airline.g8.model.Student;
import cloud.airline.g8.repository.StudentRepository;

/**
 *
 * @author Blue Maxx
 */
public class StudentServiceImp implements StudentService {

    @Autowired
    private StudentRepository studentRepository;

    @Override
    public List<Student> getAllStudent() { return studentRepository.findAll(); }

    @Override
    public Student findByName( String fullName ) {

        return studentRepository.findByName(fullName);

    }

    @Override
    public List<Student> lstStudentGreaterAvg() {

        return null;

    }

}
